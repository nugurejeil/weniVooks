import { useSelector, useDispatch } from 'react-redux'
// import { , } from '../modules/stockCounter'

function StockCounter(){

    return (
        <div>
            <p>판매중!!</p>
            <p>완판!!</p>
            {/* hint : <p>{message}</p> */}
        </div>
    )
}

export default StockCounter