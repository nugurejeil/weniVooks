const Cart = () => {
  return <div>장바구니 페이지</div>;
};

export default Cart;
