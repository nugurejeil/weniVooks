import React from "react";

function Home(props) {
  return (
    <div>
      <h1>Home 화면!</h1>
    </div>
  );
}

export default Home;
